<?php

namespace Addons\Digg\Model;
use Think\Model;

/**
 * Digg模型
 */
class DiggModel extends Model{

}
