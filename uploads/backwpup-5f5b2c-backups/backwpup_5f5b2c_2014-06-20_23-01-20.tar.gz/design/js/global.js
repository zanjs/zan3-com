// JavaScript Document
// =============改变产品图片选择状态==========================
function show_propic(showid,thumbid,picurl,src){
	// var img_count = {:count($propic)};//产品图片
	document.getElementById(showid).innerHTML = "<a href="+src+" target='_blank'><img src='"+picurl+"' title='点击查看大图'/></a>";
	for(var i=0; i< 4;i++){
		if("thumb_"+i != thumbid){			
			document.getElementById("thumb_"+i).className="hand";
		}else{
			document.getElementById("thumb_"+i).className="hand now";
		}
	}
}
